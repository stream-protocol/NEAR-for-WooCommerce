jQuery.noConflict();

window.NEAR_Data = NEAR_vars;

(function( $ ) {

    $(function() {

        window.NEAR_Data = NEAR_vars


    });

})(jQuery);

// Other code using $ as an alias to the other library